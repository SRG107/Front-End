import React from 'react';

export default function Statement1(props) {
  return (
    <div>
      <h2>Hello, {props.name}!</h2>
      <h3>Welcome to our $$ CryptoMarket $$</h3>
    </div>
  );
};
